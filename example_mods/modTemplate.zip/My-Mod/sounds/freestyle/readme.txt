Put your custom freestyle sounds here
It should be a folder with your custom song's name, and inside of it should include a ton of sounds for each note
Example: "L1.ogg", "L2.ogg", "D1.ogg", "D2.ogg", "U1.ogg", "U2.ogg", "R1.ogg", "R2.ogg"
It should be in .ogg otherwise it won't work!!!